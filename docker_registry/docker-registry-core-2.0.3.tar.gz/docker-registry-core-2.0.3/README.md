# Docker registry core

> core package for docker-registry (drivers) developers

[![PyPI version][pypi-image]][pypi-url]

## TL;DR

If you hack on the registry itself, read the registry developer doc.

If you want to write your own storage driver, this here is for you, but there is no tldr!


## What?


## License

